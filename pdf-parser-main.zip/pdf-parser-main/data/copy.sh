cat "product-details-requisition-$1.json" | clip
